package com.kaiasia.config;

public class Config {
    // AUTH API
    public static final String AUTH_API_URL = "http://14.225.254.212:8087/AUTH_API/process";
    public static final String AUTH_API_KEY = "authq51klfoni1ezxl5f2ckpfx248";

    // NAPAS API
    public static final String NAPAS_API_URL = "http://14.225.254.212:8083/NAPAS_API/process";
    public static final String NAPAS_API_KEY = "napas861klfoni1ezxl5f2ck771";

    // T24 UTIL API
    public static final String T24_UTIL_API_URL = "http://14.225.254.212:8080/T24_UTIL_API/process";
    public static final String T24_UTIL_API_KEY = "VDI0X1VUSUxfQVBJ";

    // EBANK API
    public static final String EBANK_API_URL = "http://14.225.254.212:8077/EBANK_API/process";
    public static final String EBANK_API_KEY = "custinfoq51klfoni1ezxl5f2ckpfx671";

    // FUNDSTRANSFER API
    public static final String FUNDSTRANSFER_API_URL = "http://14.225.254.212:8025/FUNDS_TRANSFER_API/process";
    public static final String FUNDSTRANSFER_API_KEY = "fundstransferh04ng14md3ptr4iv4ilu0n";

    // CUSTOMER API
    public static final String CUSTOMER_API_URL = "http://14.225.254.212:8088/CUSTOMER_API/process";
    public static final String CUSTOMER_API_KEY = "custinfoq51klfoni1ezxl5f2ckpfx671";

    // ACCOUNT API
    public static final String ACCOUNT_API_URL = "http://14.225.254.212:8089/ACCOUNT_API/process";
    public static final String ACCOUNT_API_KEY = "accountq51klfoni1ezxl5f2ckpfx248";

    private Config() {

    }
}
